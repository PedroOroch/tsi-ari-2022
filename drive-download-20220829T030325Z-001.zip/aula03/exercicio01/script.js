let video = document.getElementById('vid');

function playVideo() {
    video.play();
}

function pauseVideo() {
    video.pause();
}

function cTimeVideo(secs) {}

console.log(cTimeVideo());